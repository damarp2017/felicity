<div class="wave-wrapper <?php echo e($class??''); ?>" style="overflow: hidden;">
    <div class="wave wave1 <?php echo e($class??''); ?>">
        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             viewBox="0 0 1689.7 791" style="enable-background:new 0 0 1689.7 791;" xml:space="preserve" >

        <path fill="#FFFFFF"  d="M1689.7,0v447.9c-153.2,0-237.3,99.2-367.4,116.2c-0.1,0-0.1,0-0.2,0c-1,0.1-1.9,0.3-2.9,0.4
            c-1,0.1-2.1,0.3-3.1,0.4c-15.7,1.7-32,2.3-48.8,1.3c-16.9,1-33.1,0.4-48.8-1.3c-1-0.1-2.1-0.2-3.1-0.4
            c-131.9-15.8-216.1-116.6-370.5-116.6c-153.2,0-237.3,99.2-367.4,116.2c0,0-0.1,0-0.2,0c-1,0.1-1.9,0.3-2.9,0.4
            c-1,0.1-2.1,0.3-3.1,0.4c-15.7,1.7-32,2.3-48.8,1.3c-16.8,1-33.1,0.4-48.8-1.3c-1-0.1-2.1-0.2-3.1-0.4
            C238.6,548.7,154.4,447.9,0,447.9V0H1689.7z"/>
        </svg>
    </div>

    <div class="wave wave2 <?php echo e($class??''); ?>">
        <svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
             viewBox="0 0 1689.7 791" style="enable-background:new 0 0 1689.7 791;" xml:space="preserve" >

        <path fill="#FFFFFF"  d="M1689.7,0v447.9c-153.2,0-237.3,99.2-367.4,116.2c-0.1,0-0.1,0-0.2,0c-1,0.1-1.9,0.3-2.9,0.4
            c-1,0.1-2.1,0.3-3.1,0.4c-15.7,1.7-32,2.3-48.8,1.3c-16.9,1-33.1,0.4-48.8-1.3c-1-0.1-2.1-0.2-3.1-0.4
            c-131.9-15.8-216.1-116.6-370.5-116.6c-153.2,0-237.3,99.2-367.4,116.2c0,0-0.1,0-0.2,0c-1,0.1-1.9,0.3-2.9,0.4
            c-1,0.1-2.1,0.3-3.1,0.4c-15.7,1.7-32,2.3-48.8,1.3c-16.8,1-33.1,0.4-48.8-1.3c-1-0.1-2.1-0.2-3.1-0.4
            C238.6,548.7,154.4,447.9,0,447.9V0H1689.7z"/>
        </svg>
    </div>
</div><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/layouts/__wave.blade.php ENDPATH**/ ?>