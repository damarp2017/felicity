

<?php $__env->startPush('styles'); ?>
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Toastr -->
<script src="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.js')); ?>"></script>

<?php if($message = Session::get('success')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.success(message);
    });
</script>
<?php endif; ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Title Hero About Us</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="col-md-12">
            <div class="card card-success">
                <div class="card-header">
                    <h3 class="card-title">Title Hero About Us</h3>
                </div>
                <form action="<?php echo e(route('backoffice.static.about.us.title.hero')); ?>" method="post">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="title_hero">Title Hero</label>
                            <input type="text" class="form-control" id="title_hero" name="title_hero" required
                                placeholder="Enter Title Hero" value="<?php echo e(old('title_hero') ?? ($data ? $data->title_hero : '')); ?>">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backoffice.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/static/about_us/title_hero/edit.blade.php ENDPATH**/ ?>