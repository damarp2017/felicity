

<?php $__env->startPush('styles'); ?>
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Toastr -->
<script src="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.js')); ?>"></script>

<?php if($message = Session::get('success')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.success(message);
    });
</script>
<?php endif; ?>

<script>
	function deleteData(input, e) {
		e.preventDefault()
		const key = input.dataset.key
		$.confirm({
			title: 'Delete Data',
			content: 'are you sure to delete?',
			buttons: {
				delete: {
					text: 'Delete',
					btnClass: 'btn-danger',
					action: function() {
						document.getElementById('form-delete-'+key).submit()				
					}
				},
				cancel: {
					text: 'Cancel',
					btnClass: 'btn-success',
				}
			}
		});
	}

	$(document).on('click', '.btn-image', function (e) {  
		e.preventDefault()
		const img = $(this).data('img')
		$('#preview-img').attr('src', BASE_URL+img)
		$('#modal-image').modal('show')
	})
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Our Values</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
						<a href="<?php echo e(route('backoffice.dynamic.our.value.create')); ?>" class="btn btn-primary">Create Our Value</a>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="col-md-12">
            <div class="card card-success">
                <div class="card-header">
                    <h3 class="card-title">Our Values</h3>
                </div>
				<div class="card-body">
					<table class="table">
						<thead>
							<tr>
								<th>#</th>
								<th>Title</th>
								<th>Subtitle</th>
								<th>Action</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $ourValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($loop->iteration); ?></td>
									<td><?php echo e($value->title); ?></td>
									<td><?php echo e($value->subtitle); ?></td>
									<td>
										<a data-img="<?php echo e($value->image); ?>" class="btn btn-image btn-outline-primary btn-sm">
											<i class="fa fa-eye"></i>
										</a>
										<a href="<?php echo e(route('backoffice.dynamic.our.value.edit', $value->id)); ?>" class="btn btn-outline-warning btn-sm">
											<i class="fa fa-edit"></i>
										</a>
										<a href="" class="btn btn-outline-danger btn-sm"
										onclick="deleteData(this, event)"
										data-key="<?php echo e($loop->iteration); ?>">
											<i class="fa fa-trash"></i>
										</a>
										<form id="form-delete-<?php echo e($loop->iteration); ?>" method="POST"
											action="<?php echo e(route('backoffice.dynamic.our.value.delete', $value->id)); ?>">
											<?php echo csrf_field(); ?>
											<?php echo method_field('delete'); ?>
										</form>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
                
            </div>
        </div>
    </section>
</div>

<?php echo $__env->make('backoffice.dynamic.our_values.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backoffice.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/dynamic/our_values/index.blade.php ENDPATH**/ ?>