

<?php $__env->startPush('styles'); ?>
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Toastr -->
<script src="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.js')); ?>"></script>

<?php if($message = Session::get('success')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.success(message);
    });
</script>
<?php endif; ?>


<script>
	function previewImage(input) {  
		if (input.files && input.files[0]) {
			$('.preview-image').css('display', '')
			$('.preview-image').attr("src", URL.createObjectURL(event.target.files[0]));
			$('.preview-image').on('load', function () {  
				URL.revokeObjectURL($('.preview-image').attr("src"))
			})
		}
	}
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Edit Capability : <?php echo e($capability->title); ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="col-md-12">
			<?php if($errors->any()): ?>
				<div class="alert alert-danger">
					<ul>
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>
            <div class="card card-success">
                <div class="card-header">
                    <h3 class="card-title">Edit Capability : <?php echo e($capability->title); ?></h3>
                </div>
                <form action="<?php echo e(route('backoffice.dynamic.capablities.edit', $capability->id)); ?>" method="post"
				enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
					<?php echo method_field('put'); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control" id="title" name="title" required
                                placeholder="Enter Title" value="<?php echo e(old('title') ?? $capability->title); ?>">
                        </div>
                        <div class="form-group">
                            <label for="title">Subtitle</label>
                            <input type="text" class="form-control" id="subtitle" name="subtitle" required
                                placeholder="Enter Subtitle" value="<?php echo e(old('subtitle') ?? $capability->subtitle); ?>">
                        </div>

						<div class="form-group">
                            <label for="text_button">Text Button</label>
                            <input type="text" class="form-control" id="text_button" name="text_button" required
                                placeholder="Enter Text Button" value="<?php echo e(old('text_button') ?? $capability->text_button); ?>">
                        </div>

						<div class="form-group">
                            <label for="image">Image</label>
                            <input type="file" class="form-control" id="image" name="image"
							onchange="previewImage(this)" accept="image/*">
							<img src="<?php echo e($capability->image ? Storage::url($capability->image) : ''); ?>" class="mt-2 preview-image" alt="" width="100" height="100"
							style="object-fit: cover; object-position: center; display: <?php echo e($capability->image ? '' : 'none'); ?>">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backoffice.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/dynamic/capabilities/edit.blade.php ENDPATH**/ ?>