<?php $__env->startSection('content'); ?>
	<header class="w-full overflow-x-hidden bg--blue relative ">
		<?php echo $__env->make('layouts.__navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.__wave', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="mx-4 md:app-container 2xl:px-40">
			<!-- <img src="<?php echo e(asset('images/bg/circle-header.png')); ?>" class="absolute top-0 right-0 h-full"> -->
			<div class="flex flex-col h-screen-2/3 md:h-screen justify-center items-center text-center">
				<!-- <div class="block md:hidden text-lg text-white uppercase">We design the</div> -->
				<h1 class="text-white font-semibold md:mb-5 text-5xl md:line--height-97 md:font--size-100"><?php echo $data ? $data->title : ''; ?></h1>

				<!-- <div class="text-base md:font--size-20 text-white opacity-50 w-9/12 md:w-full">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis diam elementum <br> arcu eu cras egestas ac adipiscing. Et arcu, elementum molestie sed bland</div> -->
			</div>
		</div>
	</header>

	<section class=" bg--section w-full overflow-x-hidden overflow-y-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container 2xl:px-40">
			<?php $__currentLoopData = $capabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $capability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="tag block md:flex md:h-screen-3/4 justify-between items-center mb-20 ">
					<?php if($loop->odd): ?>
					<div class="hidden md:block w-full md:w-auto"><img class="h-auto md:h-96" src="<?php echo e(Storage::url($capability->image)); ?>"></div>
					<?php endif; ?>
					<div class="block md:hidden w-full md:w-1/2 "><img class="h-auto  md:h-96" src="<?php echo e(Storage::url($capability->image)); ?>"></div>
					<div class="w-full md:w-1/2 ">
						<h2 class="text-5xl md:font--size-70 font-bold mb-4 md:mb--23"><?php echo $capability->title; ?></h2>
						<div class="text-base md:font--size-20 text--gray line--height-160 mb-4 md:mb--28"><?php echo $capability->subtitle; ?></div>
						<a href="<?php echo e(route('capability.detail', $capability->link_button)); ?>" class="w-32 h-12 md:w--315 md:h--64 bg--blue rounded-full text-center flex justify-center items-center text-white md:font--size-18 hover:zoom"><?php echo e($capability->text_button); ?></a>
					</div>
					<?php if($loop->even): ?>
					<div class="hidden md:block w-full md:w-auto"><img class="h-auto md:h-96" src="<?php echo e(Storage::url($capability->image)); ?>"></div>
					<?php endif; ?>
				</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			

		</div>


	</section>



	<?php echo $__env->make('components.have-a-project-idea-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/capabilities.blade.php ENDPATH**/ ?>