<?php $__env->startSection('content'); ?>
	<?php echo $__env->make('layouts.__navigation_light', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<section class="bg-white w-full overflow-x-hidden py-20 md:py-10">
		<div class="mx-4 md:app-container 2xl:px-40 pt-20">
			<div class="mb-10">
				<h1 class="mb-3 md:mb-8 font-semibold text-4xl md:font--size-55 font--gilroy-bold"><?php echo e($datas ? $datas->title : ''); ?></h1>
				<!-- <div class="text--typography text-base md:font--size-18">for world-class brands to make your products to live for world-class brands to make your products to live for world-class brands to make your products to</div> -->
			</div>

			<div>
                <p><?php echo $datas ? $datas->description : ''; ?></p>

				

			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/terms_and_conditions.blade.php ENDPATH**/ ?>