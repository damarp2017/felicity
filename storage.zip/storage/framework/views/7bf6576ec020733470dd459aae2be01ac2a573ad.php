<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>" />
<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/fontawesome-free/css/all.min.css')); ?>">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/dist/css/adminlte.min.css')); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/layout/_styles.blade.php ENDPATH**/ ?>