
<?php $__env->startSection('content'); ?>
	<header class="w-full overflow-x-hidden bg--blue relative ">
		<?php echo $__env->make('layouts.__navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.__wave', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="mx-4 md:app-container">
			<!-- <img src="<?php echo e(asset('images/bg/circle-header.png')); ?>" class="absolute top-0 right-0 h-full"> -->
			<div class="flex flex-col h-screen-2/3 md:h-screen justify-center items-center" >
				<h1 class="text-white font-semibold text-3xl md:font--size-95 mb-5 text-center md:line--height-105c8"> <?php echo $data ? $data->title : ''; ?></h1>
				<!-- <div class="text-base text-center md:font--size-20 text-white opacity-50">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quis diam elementum <br> arcu eu cras egestas ac adipiscing. Et arcu, elementum molestie sed bland</div> -->
			</div>
		</div>
	</header>

	<?php echo $__env->make('components.values-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<section class="tag bg--section w-full overflow-x-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container 2xl:px-40" >
			<div class="flex flex-col items-center justify-center text-center md:mb-20">
				<div class="text-2xl md:font--size-55 font-bold mb-3 md:line--height-99c34"><?php echo $data ? $data->subtitle : ''; ?></div>
				<!-- <div class="text-base md:font--size-18 font--poppins "
				style="letter-spacing: 0.02em;
				line-height: 185.3%;
				color: rgba(0, 0, 0, 0.45);">for world-class brands to make your products to live for world-class brands to make <br> your products to live for world-class brands to make your products to</div> -->
			</div>

			
			<div class="flex flex-wrap justify-between -mx-1">
                <?php if($data): ?>
                    <?php $__currentLoopData = $data->benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefits): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-1/2 md:w-1/3 px-1 py-2 md:px-10 md:py-5">
                            <div class="h-40 md:h-60 bg-white  flex flex-col items-center justify-center card--opportunities">
                                <div class="flex items-center justify-center">
                                    <img class="mb-2 md:mb-9 h-7 md:h-20 " src="<?php echo e(Storage::url($benefits['logo'])); ?>" alt="">
                                </div>
                                <div class="text--blue text-base md:font--size-22 md:line--height-124c34 text-center">
                                    <div class="font-bold"><?php echo e($benefits['title']); ?></div>
                                    <div><?php echo e($benefits['subtitle']); ?></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			    <?php endif; ?>

				
			</div>

			<!-- 
			<div class="grid md:hidden grid-cols-2  gap-4">
				<div class="bg-white py-8 flex flex-col items-center justify-center"
				style="box-shadow: 0px -9px 46px rgba(239, 239, 239, 0.25); border-radius: 19px;" >
					<div class="flex items-center justify-center">
						<img class="mb-2 h-14 md:h-auto" src="<?php echo e(asset('images/opportunities/items/calendar.png')); ?>" alt="">
					</div>
					<div class="text--pink text-base md:font--size-30 md:line--height-124c34 text-center">
						<div class="font--gilroy-bold">Flexible</div>
						<div class="font--gilroy-reg">Time Schedule</div>
					</div>
				</div>

				<div class="bg-white py-8 flex flex-col items-center justify-center"
				style="box-shadow: 0px -9px 46px rgba(239, 239, 239, 0.25); border-radius: 19px;">
					<div class="flex items-center justify-center">
						<img class="mb-2 h-14 md:h-auto" src="<?php echo e(asset('images/opportunities/items/learing.png')); ?>" alt="">
					</div>
					<div class="text--pink text-base md:font--size-30 md:line--height-124c34 text-center">
						<div class="font--gilroy-bold">Learing and </div>
						<div class="font--gilroy-reg">Development</div>
					</div>
				</div>

				<div class="bg-white py-8 flex flex-col items-center justify-center"
				style="box-shadow: 0px -9px 46px rgba(239, 239, 239, 0.25); border-radius: 19px;">
					<div class="flex items-center justify-center">
						<img class="mb-2 h-14 md:h-auto" src="<?php echo e(asset('images/opportunities/items/love.png')); ?>" alt="">
					</div>
					<div class="text--pink text-base md:font--size-30 md:line--height-124c34 text-center">
						<div class="font--gilroy-bold">Generous Parental  </div>
						<div class="font--gilroy-reg"><span class="font--gilroy-bold">and</span> Family Leaves</div>
					</div>
				</div>

				<div class="bg-white py-8 flex flex-col items-center justify-center"
				style="box-shadow: 0px -9px 46px rgba(239, 239, 239, 0.25); border-radius: 19px;">
					<div class="flex items-center justify-center">
						<img class="mb-2 h-14 md:h-auto" src="<?php echo e(asset('images/opportunities/items/headspace.png')); ?>" alt="">
					</div>
					<div class="text--pink text-base md:font--size-30 md:line--height-124c34 text-center">
						<div class="font--gilroy-bold">Headspace</div>
						<div class="font--gilroy-reg">Membership</div>
					</div>
				</div>
				<div class="bg-white py-8 flex flex-col items-center justify-center"
				style="box-shadow: 0px -9px 46px rgba(239, 239, 239, 0.25); border-radius: 19px;">
					<div class="flex items-center justify-center">
						<img class="mb-2 h-14 md:h-auto" src="<?php echo e(asset('images/opportunities/items/book.png')); ?>" alt="">
					</div>
					<div class="text--pink text-base md:font--size-30 md:line--height-124c34 text-center">
						<div class="font--gilroy-bold">Book</div>
						<div class="font--gilroy-reg">Reimbursements</div>
					</div>
				</div>

				<div class="bg-white py-8 flex flex-col items-center justify-center"
				style="box-shadow: 0px -9px 46px rgba(239, 239, 239, 0.25); border-radius: 19px;">
					<div class="flex items-center justify-center">
						<img class="mb-2 h-14 md:h-auto" src="<?php echo e(asset('images/opportunities/items/time.png')); ?>" alt="">
					</div>
					<div class="text--pink text-base md:font--size-30 md:line--height-124c34 text-center">
						<div class="font--gilroy-bold">Paid Volunteer </div>
						<div class="font--gilroy-reg">Time</div>
					</div>
				</div>
			</div> -->
		</div>
	</section>

	<section class="tag bg-white w-full overflow-x-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container 2xl:px-40">
            <?php if($data): ?>
                <?php $__currentLoopData = $data->reasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reasons): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="block md:flex items-center justify-between mb-5 md:mb-20">
						<?php if($loop->odd): ?>
							<div class="w-full md:w-1/2 md:mr--84">
								<img class="w-full" src="<?php echo e(Storage::url($reasons['image'])); ?>" alt="">
							</div>	
						<?php endif; ?>
                        
                        <div class="w-full md:w-1/2">
                            <h2 class="mb-2 md:mb-10 font-semibold text-2xl md:font--size-38"><?php echo e(($reasons['title'])); ?></h2>
                            <div class="text--gray line--height-160 text-base md:font--size-20 w-full"><?php echo e(($reasons['description'])); ?></div>
                        </div>
						<?php if($loop->even): ?>
							<div class="w-full md:w-1/2 md:mr--84">
								<img class="w-full" src="<?php echo e(Storage::url($reasons['image'])); ?>" alt="">
							</div>	
						<?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

			
		</div>
	</section>

	<section class="tag bg--section w-full overflow-x-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container 2xl:px-40">
			<div class="mb-0 md:mb--51">
				<h2 class="text-2xl md:font--size-55 mb-6 md:mb-10 font-bold md:line--height-99c34">Purpose driven team on a  <br> <span class="text--blue">global mission</span> </h2>
				<div class=" text-base md:font--size-20 text--gray line--height-160">(No open positions currently. Check again later.)</div>
			</div>

			<!-- <div class="relative mr-6 my-10 md:mb--58 w-full">
				<input type="text" class="bg-white text--black-op-87 font--poppins w-full md:font--size-16 focus:outline-none rounded-xl border-0 px-3 py-3 md:padding-form-search-jobs" placeholder="Search Any Position . . .">
				<div class="absolute top-0 right-0 transform translate-y-1/2 pin-r pin-t mt-3 mr-4 text-purple-lighter">
					<svg version="1.1" class="h-4 text-dark" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 52.966 52.966" style="enable-background:new 0 0 52.966 52.966;" xml:space="preserve"> <path d="M51.704,51.273L36.845,35.82c3.79-3.801,6.138-9.041,6.138-14.82c0-11.58-9.42-21-21-21s-21,9.42-21,21s9.42,21,21,21 c5.083,0,9.748-1.817,13.384-4.832l14.895,15.491c0.196,0.205,0.458,0.307,0.721,0.307c0.25,0,0.499-0.093,0.693-0.279 C52.074,52.304,52.086,51.671,51.704,51.273z M21.983,40c-10.477,0-19-8.523-19-19s8.523-19,19-19s19,8.523,19,19 S32.459,40,21.983,40z"/></svg>
				</div>
			</div>

			<div>
				<div class="uppercase my-4 md:mb--24 text-sm font--gilroy-md md:font--size-14 text--black-op-87" >Filters</div>
				<div class="grid grid-flow-col auto-cols-max gap-x-5 md:gap-x-0 mb-10 md:mb--87 overflow-x-auto md:overflow-x-hidden ">
					<a href="#" class="filter-link md:mr--3 font--gilroy-md rounded-lg py-3 px-5 md:padding-button-filter-jobs text--gray-66 md:font--size-17 focus:bg--blue focus:text--white-op-87" style="letter-spacing: 0.02em;">UI/UX Designer</a>
					<a href="#" class="filter-link md:mr--3 font--gilroy-md rounded-lg py-3 px-5 md:padding-button-filter-jobs text--gray-66 md:font--size-17 focus:bg--blue focus:text--white-op-87" style="letter-spacing: 0.02em;">Web Designer</a>
					<a href="#" class="filter-link md:mr--3 font--gilroy-md rounded-lg py-3 px-5 md:padding-button-filter-jobs text--gray-66 md:font--size-17 focus:bg--blue focus:text--white-op-87" style="letter-spacing: 0.02em;">Graphic Designer</a>
					<a href="#" class="filter-link md:mr--3 font--gilroy-md rounded-lg py-3 px-5 md:padding-button-filter-jobs text--gray-66 md:font--size-17 focus:bg--blue focus:text--white-op-87" style="letter-spacing: 0.02em;">Content writer</a>
				</div>

				<div class="uppercase mb-6 md:mb--21 text-sm font--gilroy-md md:font--size-14 text--black-op-87">AVAILABLE POSITIONS</div>
				<div class="grid grid-cols-1 md:flex md:flex-row mb-6 flex-wrap gap-6 md:gap-0 md:-mr--59">
					<?php for($i = 0; $i < 6; $i++): ?>
					<div class="card-jobs-sm md:card-jobs bg-white md:mr--41 last:mr-0">
						<div class="font-semibold mb-2 text-lg md:font--size-24 font--gilroy-bold">Senior UI/UX Designer</div>
						<div class="mb-6 text--desc-jobs">for world-class brands to make your products to live for world-class brands to make your products to live for world-class brands to make your products to</div>
						<a href="" class="flex justify-end mt--17 mb--29">
							<img class="h-4" src="<?php echo e(asset('images/utilities/next.png')); ?>" alt="">
						</a>
					</div>
					<?php endfor; ?>
				</div>

				<div class="flex justify-center">
					<button class="bg--gradient-black rounded-full w-40 h-14 md:w--284 md:h--66 text-white md:font--size-20">Show More</button>
				</div>
			</div> -->
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
	<script>
		const links = document.querySelectorAll('.filter-link')
		Array.from(links).forEach(link => {
			link.addEventListener('click', function (e) {
				e.preventDefault()
			})
		})

	</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/opportunities.blade.php ENDPATH**/ ?>