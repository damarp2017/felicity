<div class="card">
	<div class="card-body">
		<a href="<?php echo e(route('backoffice.dynamic.capabilities.title.subtitle.edit', $capabilityId)); ?>" class="nav-link <?php echo e(request()->routeIs('backoffice.dynamic.capabilities.title.subtitle.*') ? 'bg-primary rounded' : ''); ?>">
			Title Detail - Subtitle
		</a>
		<a href="<?php echo e(route('backoffice.dynamic.our.process.index', $capabilityId)); ?>" class="nav-link <?php echo e(request()->routeIs('backoffice.dynamic.our.process.*') ? 'bg-primary rounded' : ''); ?>">
			Our Process
		</a>
		<a href="<?php echo e(route('backoffice.dynamic.what.include.index', $capabilityId)); ?>" class="nav-link <?php echo e(request()->routeIs('backoffice.dynamic.what.include.*') ? 'bg-primary rounded' : ''); ?>">
			Whats Included
		</a>
	</div>
</div><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/dynamic/capabilities_detail/_sidebar.blade.php ENDPATH**/ ?>