

<?php $__env->startPush('styles'); ?>
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Toastr -->
<script src="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.js')); ?>"></script>

<?php if($message = Session::get('success')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.success(message);
    });
</script>
<?php endif; ?>

<script>
	function previewImage(input) {  
		if (input.files && input.files[0]) {
			$('.preview-image').css('display', '')
			$('.preview-image').attr("src", URL.createObjectURL(event.target.files[0]));
			$('.preview-image').on('load', function () {  
				URL.revokeObjectURL($('.preview-image').attr("src"))
			})
		}
	}
</script>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Title Detail - Subtitle</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.setting')); ?>">Title Detail - Subtitle</a></li>
                        
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
		<?php if($errors->any()): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><?php echo e($error); ?></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
		<?php endif; ?>
		<div class="d-flex">
			<div class="col-md-3">
				<?php echo $__env->make('backoffice.dynamic.capabilities_detail._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			</div>
			<div class="col-md-9">
				<div class="card">
					<div class="card-header">
						<h3 class="card-title">Title Detail - Subtitle</h3>
					</div>
					<form action="<?php echo e(route('backoffice.dynamic.capabilities.title.subtitle.edit', $capabilityId)); ?>" method="post">
						<?php echo method_field('put'); ?>
						<?php echo csrf_field(); ?>
						<div class="card-body">
							<div class="form-group">
								<label for="title_detail">Title Detail</label>
								<input type="text" class="form-control" id="title_detail" name="title_detail" required
									placeholder="Enter Title Detail" value="<?php echo e(old('title_detail') ?? ($data ? $data->title_detail : '')); ?>">
							</div>

							<div class="form-group">
								<label for="subtitle">Subtitle</label>
								<input type="text" class="form-control" id="subtitle" name="subtitle" required
									placeholder="Enter subtitle" value="<?php echo e(old('subtitle') ?? ($data ? $data->subtitle : '')); ?>">
							</div>
						</div>
						<div class="card-footer">
							<button type="submit" class="btn btn-success">Update</button>
						</div>
					</form>
				</div>
				
			</div>
		</div>
		
        
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backoffice.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/dynamic/capabilities_detail/title_subtitle/index.blade.php ENDPATH**/ ?>