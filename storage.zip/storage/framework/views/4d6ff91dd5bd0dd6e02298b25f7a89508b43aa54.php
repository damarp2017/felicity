<?php $__env->startSection('content'); ?>
	<header class="w-full overflow-x-hidden bg--blue relative">
		<?php echo $__env->make('layouts.__navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.__wave', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="mx-4 md:app-container">
			<!-- <img src="<?php echo e(asset('images/bg/circle-header.png')); ?>" class="absolute top-0 right-0 h-full"> -->
			<div class="flex flex-col h-96 md:h-screen justify-center items-center text-center" >
				<h1 class="text-white font-semibold text-4xl md:line--height-97 md:font--size-100 mb-5 md:mb-0 text-center"><?php echo e($data ? $data->title_hero : ''); ?></h1>
				<!-- <div class="text-sm md:font--size-20 text-white opacity-50 w-3/4"></div> -->
			</div>
		</div>
	</header>

	<section class="bg--section w-full overflow-x-hidden py-10 md:pb-20 md:pt--137">
		<div class="mx-4 md:app-container">
			<div class="block md:flex mb-10 flex-col">
				<h2 class="mb-6 text-3xl md:font--size-55 font-semibold"><?php echo $data ? $data->title : ''; ?></h2>
				<div class="text-sm md:font--size-20 line--height-160 " style="color: #898989"><?php echo $data ? $data->subtitle : ''; ?></div>
			</div>
		</div>
		<div class="mx-4 md:app-container">
			<?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($loop->iteration <=2): ?>
                    <div class="block md:flex mb-10 md:mb-24 items-center">
                        <div class="block md:hidden w-full md:w-1/2">
                            <img class="h-auto md:h-96" src="<?php echo e(Storage::url($content['image'])); ?>">
                        </div>
                        <?php if($loop->odd): ?>
                            <div class="hidden md:block md:w--459">
                                <img src="<?php echo e(Storage::url($content['image'])); ?>">
                            </div>
                            <div class="hidden md:block md:w--186"></div>
                        <?php endif; ?>
                        <div class="w-full md:w--549">
                            <div class="mb-3 text-black ">
                                <h2 class=" text-3xl md:font--size-70 font-bold md:mb-10 md:line--height-99c34"><?php echo ($content['title']); ?></h2>
                            </div>
                            <div class="text-sm md:font--size-20 line--height-160 text--gray mb-4"><?php echo e(($content['subtitle'])); ?></div>
                        </div>
                        <?php if($loop->even): ?>
                        <div class="hidden md:block md:w--186"></div>
                            <div class="hidden md:block md:w--459">
                                <img src="<?php echo e(Storage::url($content['image'])); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			

			
		</div>
	</section>

	<?php echo $__env->make('components.values-section', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<section class="bg--section w-full overflow-x-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container">
            <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($loop->iteration > 2): ?>
                    <div class="block md:flex mb-10 md:mb-24 items-center">
                        <div class="block md:hidden w-full md:w-1/2">
                            <img class="h-auto md:h-96" src="<?php echo e(Storage::url($content['image'])); ?>">
                        </div>
                        <?php if($loop->odd): ?>
                            <div class="hidden md:block md:w--459">
                                <img src="<?php echo e(Storage::url($content['image'])); ?>">
                            </div>
                            <div class="hidden md:block md:w--186"></div>
                        <?php endif; ?>
                        <div class="w-full md:w--549">
                            <div class="mb-3 text-black ">
                                <h2 class=" text-3xl md:font--size-70 font-bold md:mb-10 md:line--height-99c34"><?php echo ($content['title']); ?></h2>
                            </div>
                            <div class="text-sm md:font--size-20 line--height-160 text--gray mb-4"><?php echo e(($content['subtitle'])); ?></div>
                        </div>
                        <?php if($loop->even): ?>
                        <div class="hidden md:block md:w--186"></div>
                            <div class="hidden md:block md:w--459">
                                <img src="<?php echo e(Storage::url($content['image'])); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			

		</div>
	</section>

	<section class="bg-white w-full overflow-x-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container md:pt-20">
			<div class="block md:flex items-center">
				<div class="w-full md:w-1/2">
					<img class="h-auto md:h-96" src="<?php echo e(asset('images/home/join.png')); ?>" alt="">
				</div>
				<div class="w-full md:w-1/2">
					<h2 class="text-3xl md:font--size-75 font-semibold mb-4 md:mb-10">Join the <span class="text--blue">Team</span></h2>
					<div class="text-sm md:font--size-20 text--gray mb-10 md:mb-14" style="line-height: 160%;">Our vision of taking India to the world is impossible without the help of honest, talented, and purpose driven individuals. We are on a constant lookout for people that believe in the power of ideas and dare to change the world with their own.</div>
					<a href="<?php echo e(url('opportunities')); ?>" class="flex justify-center items-center bg--blue rounded-full text-sm md:font--size-18 text-white w-32 h-12 md:w--244 md:h--60">Explore Profiles</a>
				</div>
			</div>
		</div>

	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/about_us.blade.php ENDPATH**/ ?>