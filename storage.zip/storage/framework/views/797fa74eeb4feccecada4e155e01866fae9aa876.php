

<?php $__env->startPush('styles'); ?>
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- bs-custom-file-input -->
<script src="<?php echo e(asset('assets/adminlte/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<!-- Toastr -->
<script src="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.js')); ?>"></script>

<script>
    $(function () {
        bsCustomFileInput.init();
    });
</script>

<?php if($message = Session::get('success')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.success(message);
    });
</script>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.error(message);
    });
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Home</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.static.home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a
                                href="<?php echo e(route('backoffice.static.home.visionAndManifesto')); ?>">Vision
                                and Manifesto</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="col-md-12">
            <div class="card card-success">
                <div class="card-header">
                    <h3 class="card-title">Vision and Manifesto</h3>
                </div>
                <form action="<?php echo e(route('backoffice.static.home.updateVisionAndManifesto')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="vision">Vision Title</label>
                            <input type="text" class="form-control" id="vision" name="vision" required
                                placeholder="Enter vision title" value="<?php echo e(old('vision') ?? $data->vision); ?>">
                            <div class="form-group">
                                <label for="vision_description">Vision Description</label>
                                <textarea type="text" class="form-control" id="vision_description"
                                    name="vision_description" required
                                    placeholder="Enter vision description"><?php echo e(old('vision_description') ?? $data->vision_description); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <img src="<?php echo e($data->manifesto_image); ?>" style="max-height: 300px; width: auto"
                                alt="Manifesto Image">
                        </div>
                        <div class="form-group">
                            <label for="manifestoImage">Manifesto Image</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="manifesto_image"
                                        name="manifesto_image">
                                    <label class="custom-file-label" for="manifesto_image">Choose Manifesto
                                        Image</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="manifesto">Manifesto Title</label>
                            <input type="text" class="form-control" id="manifesto" name="manifesto" required
                                placeholder="Enter manifesto title" value="<?php echo e(old('manifesto') ?? $data->manifesto); ?>">
                        </div>
                        <div class="form-group">
                            <label for="manifesto_description">Manifesto Description</label>
                            <textarea type="text" class="form-control" id="manifesto_description"
                                name="manifesto_description" required
                                placeholder="Enter our manifesto description"><?php echo e(old('manifesto_description') ?? $data->manifesto_description); ?></textarea>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>
<div id="modal-wrapper"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backoffice.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/static/home/vision-and-manifesto.blade.php ENDPATH**/ ?>