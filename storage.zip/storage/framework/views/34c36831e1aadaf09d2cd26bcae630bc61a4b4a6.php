	<section class="tag bg-white w-full overflow-x-hidden py-10 md:py-20">
		<div class="mx-4 md:app-container 2xl:px-40">
			<div class="flex ">
				<!-- <div class="mr-4"><img class="w-8 md:w-10 h-1" src="<?php echo e(asset('images/utilities/hr.png')); ?>"></div> -->
				<h1 class="text--blue text-3xl md:font--size-39 font-bold">Our Values</h1>
			</div>
		</div>
		<div class="2xl:px-40">
			<div class="flex overflow-x-auto pt-5 slider" id="values-slider">
				
				<?php $__currentLoopData = $ourValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div style="min-width: 100vw;">
					<div class="block md:flex mx-4 md:app-container">
						<div class="w-full md:w-1/2">
							<img class="max-h-80 max-w-full" src="<?php echo e(Storage::url($item->image)); ?>">
						</div>
						<div class="w-full md:w-1/2">
							<div class="mb-3 text-black ">
								<div class="flex gap-x-4 items-center">
									<div class="text-2xl md:font--size-30"><?php echo e(str_pad($loop->iteration,2,STR_PAD_LEFT,'0')); ?></div>
									<div class="w-48"><hr></div>
								</div>
								<h2 class=" text-3xl mt-3 md:mt--11 mb-6 md:mb--34 md:font--size-65 font-bold md:line--height-107c84"><?php echo e($item->title); ?></h2>
							</div>
							<div class="text-base md:font--size-20 line--height-160 text--gray mb-4"><?php echo e($item->subtitle); ?></div>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="mx-4 md:app-container 2xl:px-40">
			<div class="flex justify-between items-center">
				<div class="flex gap-x-2 items-center slider-dot">
					<div class="bg--blue w-10 h-1 md:h-2 rounded-full"></div>
					<div class="bg-gray-300 w-5 h-1 md:h-2 rounded-full"></div>
					<div class="bg-gray-300 w-5 h-1 md:h-2 rounded-full"></div>
				</div>
				<div class="flex gap-x-4 items-center">
					<div class=" hover:zoom bg-gray-200 w-10 h-10 md:w--64 md:h--64 flex items-center justify-center rounded-full slider-control" target="#values-slider" action="prev">
						<img class="h-3 md:h-auto" src="<?php echo e(asset('images/utilities/prev.png')); ?>">
					</div>
					<div class=" hover:zoom bg-gray-200 w-10 h-10 md:w--64 md:h--64 flex items-center justify-center rounded-full slider-control" target="#values-slider" action="next">
						<img class="h-3 md:h-auto" src="<?php echo e(asset('images/utilities/next.png')); ?>">
					</div>
				</div>
			</div>
		</div>
	</section><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/components/values-section.blade.php ENDPATH**/ ?>