<!-- jQuery -->
<script src="<?php echo e(asset('assets/adminlte/plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('assets/adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- AdminLTE App -->
<script src="<?php echo e(asset('assets/adminlte/dist/js/adminlte.min.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('assets/adminlte/dist/js/demo.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

<script>
	const BASE_URL = "<?php echo e(env('APP_URL')); ?>"
</script><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/layout/_scripts.blade.php ENDPATH**/ ?>