

<?php $__env->startPush('styles'); ?>
<!-- Toastr -->
<link rel="stylesheet" href="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- bs-custom-file-input -->
<script src="<?php echo e(asset('assets/adminlte/plugins/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
<!-- Toastr -->
<script src="<?php echo e(asset('assets/adminlte/plugins/toastr/toastr.min.js')); ?>"></script>

<script>
    $(function () {
        bsCustomFileInput.init();
    });
</script>

<script>
    function showAlertModal(index) {
        const url = "<?php echo e(route('backoffice.static.home.deleteMissions', '')); ?>" + '/' + index;
        const modal = `
        <div class="modal fade" id="modal-danger">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header bg-danger">
                        <h4 class="modal-title">Warning</h4>
                    </div>
                    <form action="${url}" method="post">
                        <?php echo method_field('delete'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <p>Are you sure to delete this data?</p>
                        </div>
                        <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-outline-danger">Yes, sure</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        `;
        $('#modal-wrapper').html(modal);
        $('#modal-danger').modal('show');
    }
</script>

<?php if($message = Session::get('success')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.success(message);
    });
</script>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<script>
    message = <?php echo json_encode($message); ?>

    $(function() {
        toastr.error(message);
    });
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Missions</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('backoffice.static.home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a
                                href="<?php echo e(route('backoffice.static.home.missions')); ?>">Missions</a></li>
                    </ol>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Add New Missions</h3>
                </div>
                <form action="<?php echo e(route('backoffice.static.home.storeMissions')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="manifestoDescription">Mission Logo</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="logo" name="logo" required>
                                    <label class="custom-file-label" for="logo">Choose Mission Logo</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="sequence">Sequence Number</label>
                            <input type="number" class="form-control" id="sequence" name="sequence" required
                                placeholder="Enter sequence number" value="<?php echo e(old('sequence')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="title">Mission Title</label>
                            <input type="text" class="form-control" id="title" name="title" required
                                placeholder="Enter our mission title" value="<?php echo e(old('title')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="subtitle">Mission Subtitle</label>
                            <input type="text" class="form-control" id="subtitle" name="subtitle" required
                                placeholder="Enter our mission subtitle" value="<?php echo e(old('subtitle')); ?>">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-sm-12">
            <?php $__currentLoopData = collect($data->missions)->sortBy('sequence')->toArray(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card card-success">
                <div class="card-header">
                    <h3 class="card-title">Mission: <?php echo e($mission['sequence']); ?></h3>
                </div>
                <form action="<?php echo e(route('backoffice.static.home.updateMissions', $key)); ?>" enctype="multipart/form-data"
                    method="POST">
                    <?php echo method_field('patch'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-group">
                            <img src="<?php echo e(Storage::url($mission['logo'])); ?>" alt="Mission Logo"
                                style="height: 60px; width: auto;">
                        </div>
                        <div class="form-group">
                            <label for="manifestoDescription">Mission Logo</label>
                            <div class="input-group">
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="logo" name="logo">
                                    <label class="custom-file-label" for="logo">Choose Mission Logo</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="sequence">Sequence Number</label>
                            <input type="number" class="form-control" id="sequence" name="sequence"
                                placeholder="Enter sequence number" required
                                value="<?php echo e(old('sequence') ?? $mission['sequence']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="title">Mission Title</label>
                            <input type="text" class="form-control" id="title" name="title"
                                placeholder="Enter our mission title" required
                                value="<?php echo e(old('title') ?? $mission['title']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="subtitle">Mission Subtitle</label>
                            <input type="text" class="form-control" id="subtitle" name="subtitle"
                                placeholder="Enter our mission subtitle" required
                                value="<?php echo e(old('subtitle') ?? $mission['subtitle']); ?>">
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-success">Update</button>&ensp;
                        <a href="javascript:void(0)" onclick="showAlertModal(<?php echo e($key); ?>)"
                            class="text-danger"><u>Delete</u></a>
                    </div>
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
</div>
<div id="modal-wrapper"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backoffice.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\project.co.id\felicity\resources\views/backoffice/static/home/missions.blade.php ENDPATH**/ ?>